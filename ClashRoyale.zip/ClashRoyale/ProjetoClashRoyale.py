from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QLineEdit, QFileDialog, QListWidget
from PyQt5.QtGui import QPixmap
from PyQt5.QtGui import QFont, QPalette, QColor
from PyQt5.QtCore import Qt
import sys

import sqlite3


def criar_banco():
    conn = sqlite3.connect("cartas.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS cartas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT,
        imagem TEXT
    )
    """)

    conn.commit()
    conn.close()

def listar_cartas():
    conn = sqlite3.connect("cartas.db")
    cursor = conn.cursor()

    cursor.execute("SELECT nome, imagem FROM cartas LIMIT 6")
    cartas = cursor.fetchall()

    conn.close()
    return cartas


class QuintaTela(QWidget):
    def __init__(self, tela_cartas):
        super().__init__()

        self.tela_cartas = tela_cartas

        self.setWindowTitle("Quinta Tela")
        self.resize(1000, 700)
        self.setStyleSheet("background-color: #324B76;")
        
        self.titulo = QLabel("Apague uma Carta", self)
        self.titulo.move(240, 50)
        self.titulo.setStyleSheet("font-size: 60px; font-weight: bold; color: #FFB33E;")

        
        self.lista = QListWidget(self)
        self.lista.setGeometry(330, 250, 360, 250)
        self.lista.setStyleSheet("font-size: 20px; font-weight: bold; background-color: #527A9E; color: white;")

        
        self.botao_excluir = QPushButton("Apagar", self)
        self.botao_excluir.setGeometry(730, 360, 150, 40)
        self.botao_excluir.setStyleSheet("font-size: 25px; font-weight: bold; color: white; background-color: #FFB33E;")
        self.botao_excluir.clicked.connect(self.excluir)

        self.botao_excluir = QPushButton("Voltar", self)
        self.botao_excluir.setGeometry(440, 580, 150, 40)
        self.botao_excluir.setStyleSheet("font-size: 25px; font-weight: bold; color: white; background-color: #08AEF6;")
        self.botao_excluir.clicked.connect(self.voltar)

        self.carregar_lista()
    
    def voltar(self):
        self.close()

    def carregar_lista(self):
        
        conn = sqlite3.connect("cartas.db")
        cursor = conn.cursor()

        cursor.execute("SELECT nome FROM cartas")
        dados = cursor.fetchall()

        conn.close()

        for nome in dados:
            self.lista.addItem(nome[0])

    def excluir(self):
        
        item = self.lista.currentItem()
        if not item:
            return

        nome = item.text()

        
        conn = sqlite3.connect("cartas.db")
        cursor = conn.cursor()

        cursor.execute("DELETE FROM cartas WHERE nome = ?", (nome,))
        conn.commit()
        conn.close()

        self.tela_cartas.atualizar_cartas()
        self.lista.takeItem(self.lista.currentRow())




class QuartaTela(QWidget):
    def __init__(self, tela1):
        super().__init__()

        self.tela1 = tela1

        self.setWindowTitle("Quarta Tela")
        self.resize(1000, 700)
        self.setStyleSheet("background-color: #324B76;")
        
        self.titulo = QLabel("Cartas Predefinidas", self)
        self.titulo.move(220, 50)
        self.titulo.setStyleSheet("font-size: 60px; font-weight: bold; color: #FFB33E;")

        self.carta1 = QPushButton("Mago", self)
        self.carta1.setGeometry(20, 280, 300, 100)
        self.carta1.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #69D458;")
        self.carta1.clicked.connect(self.mudar_carta1)

        self.carta2 = QPushButton("Pekka", self)
        self.carta2.setGeometry(350, 280, 300, 100)
        self.carta2.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #69D458;")
        self.carta2.clicked.connect(self.mudar_carta2)

        self.carta3 = QPushButton("Executor", self)
        self.carta3.setGeometry(680, 280, 300, 100)
        self.carta3.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #69D458;")
        self.carta3.clicked.connect(self.mudar_carta3)

        self.carta4 = QPushButton("Fornalha", self)
        self.carta4.setGeometry(20, 430, 300, 100)
        self.carta4.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #69D458;")
        self.carta4.clicked.connect(self.mudar_carta4)

        self.carta5 = QPushButton("Porcos Reais", self)
        self.carta5.setGeometry(350, 430, 300, 100)
        self.carta5.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #69D458;")
        self.carta5.clicked.connect(self.mudar_carta5)

        self.carta6 = QPushButton("Principe", self)
        self.carta6.setGeometry(680, 430, 300, 100)
        self.carta6.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #69D458;")
        self.carta6.clicked.connect(self.mudar_carta6)

        self.botao = QPushButton("Voltar", self)
        self.botao.move(350, 590)
        self.botao.resize(300, 60)
        self.botao.setStyleSheet("font-size: 25px; font-weight: bold; color: white; background-color: #08AEF6;")
        self.botao.clicked.connect(self.voltar)
        
    def voltar(self):
        self.close()
    
    def mudar_carta6(self):
        self.tela1.mudar_imagem("principe.png")
        self.close()

    def mudar_carta5(self):
        self.tela1.mudar_imagem("porcos-reais.png")
        self.close()

    def mudar_carta4(self):
        self.tela1.mudar_imagem("fornalha.png")
        self.close()

    def mudar_carta3(self):
        self.tela1.mudar_imagem("executor.png")
        self.close()

    def mudar_carta2(self):
        self.tela1.mudar_imagem("pekka.png")
        self.close()

    def mudar_carta1(self):
        self.tela1.mudar_imagem("mago.png")
        self.close()





class TerceiraTela(QWidget):
    def __init__(self, tela1):
        super().__init__()

        self.tela1 = tela1
        criar_banco()

        self.setWindowTitle("Terceira Tela")
        self.resize(1000, 700)
        self.setStyleSheet("background-color: #324B76;")

        self.titulo = QLabel("Cartas Criadas", self)
        self.titulo.move(290, 50)
        self.titulo.setStyleSheet("font-size: 60px; font-weight: bold; color: #FFB33E;")

        self.escolher = QLabel("Escolha uma carta preferida:", self)
        self.escolher.move(20, 180)
        self.escolher.setStyleSheet("font-size: 30px; font-weight: bold; color: #FFB33E;")

        self.carta1 = QPushButton("Carta generica", self)
        self.carta1.setGeometry(20, 280, 300, 100)
        self.carta1.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #527A9E;")

        self.carta2 = QPushButton("Carta generica", self)
        self.carta2.setGeometry(350, 280, 300, 100)
        self.carta2.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #527A9E;")

        self.carta3 = QPushButton("Carta generica", self)
        self.carta3.setGeometry(680, 280, 300, 100)
        self.carta3.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #527A9E;")
        
        self.carta4 = QPushButton("Carta generica", self)
        self.carta4.setGeometry(20, 430, 300, 100)
        self.carta4.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #527A9E;")

        self.carta5 = QPushButton("Carta generica", self)
        self.carta5.setGeometry(350, 430, 300, 100)
        self.carta5.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #527A9E;")

        self.carta6 = QPushButton("Carta generica", self)
        self.carta6.setGeometry(680, 430, 300, 100)
        self.carta6.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #527A9E;")

        self.botao = QPushButton("Voltar", self)
        self.botao.move(550, 590)
        self.botao.resize(300, 60)
        self.botao.setStyleSheet("font-size: 25px; font-weight: bold; color: white; background-color: #08AEF6;")
        self.botao.clicked.connect(self.voltar)

        self.botao2 = QPushButton("Apagar carta", self)
        self.botao2.move(150, 590)
        self.botao2.resize(300, 60)
        self.botao2.setStyleSheet("font-size: 25px; font-weight: bold; color: white; background-color: #FFB33E;")
        self.botao2.clicked.connect(self.abrirQuintaTela)

        self.carta1.clicked.connect(lambda: self.selecionar_carta(0))
        self.carta2.clicked.connect(lambda: self.selecionar_carta(1))
        self.carta3.clicked.connect(lambda: self.selecionar_carta(2))
        self.carta4.clicked.connect(lambda: self.selecionar_carta(3))
        self.carta5.clicked.connect(lambda: self.selecionar_carta(4))
        self.carta6.clicked.connect(lambda: self.selecionar_carta(5))


        self.atualizar_cartas()
        
        
    def voltar(self):
        self.close()

    
    def atualizar_cartas(self):
        cartas = listar_cartas()

        
        if len(cartas) > 0:
            nome, img = cartas[0]
            self.carta1.setText(nome)
        else:
            self.carta1.setText("Carta vazia")

        
        if len(cartas) > 1:
            nome, img = cartas[1]
            self.carta2.setText(nome)
        else:
            self.carta2.setText("Carta vazia")

        
        if len(cartas) > 2:
            nome, img = cartas[2]
            self.carta3.setText(nome)
        else:
            self.carta3.setText("Carta vazia")

        
        if len(cartas) > 3:
            nome, img = cartas[3]
            self.carta4.setText(nome)
        else:
            self.carta4.setText("Carta vazia")

        
        if len(cartas) > 4:
            nome, img = cartas[4]
            self.carta5.setText(nome)
        else:
            self.carta5.setText("Carta vazia")

        
        if len(cartas) > 5:
            nome, img = cartas[5]
            self.carta6.setText(nome)
        else:
            self.carta6.setText("Carta vazia")

    def selecionar_carta(self, indice):
        conn = sqlite3.connect("cartas.db")
        cursor = conn.cursor()

        cursor.execute("SELECT nome, imagem FROM cartas")
        cartas = cursor.fetchall()

        conn.close()

        if indice < len(cartas):
            nome, caminho = cartas[indice]
    
            self.tela1.atualizar_imagem(caminho)

            self.close()

    def abrirQuintaTela(self):
        self.janela5 = QuintaTela(self)
        self.janela5.show()

   

class SegundaTela(QWidget):
    def __init__(self):
        super().__init__()

        criar_banco()

        self.setWindowTitle("Segunda Tela")
        self.resize(1000, 700)
        self.setStyleSheet("background-color: #324B76;")


        self.nome = QLabel("Digite o nome da carta:", self)
        self.nome.move(310, 520)
        self.nome.setStyleSheet("font-size: 20px; font-weight: bold; color: #FFB33E;")

        self.botao2 = QPushButton("Criar Carta", self)
        self.botao2.setGeometry(400, 630, 200, 40)
        self.botao2.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #FFB33E;")
        self.botao2.clicked.connect(self.botao_criar)


        self.label_imagem = QLabel(self)
        self.label_imagem.setGeometry(300, 50, 400, 350) 

        
        self.botao = QPushButton("Adicionar Imagem", self)
        self.botao.setGeometry(400, 420, 200, 40)
        self.botao.clicked.connect(self.abrirImagem)
        self.botao.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: #08AEF6;")


        self.entrada = QLineEdit(self)
        self.entrada.move(305, 550)
        self.entrada.resize(400, 50)
        self.entrada.setStyleSheet("font-size: 18px; color: white; background-color: #4a5464;")

    def botao_criar(self):
        self.salvar_carta()
        self.close()
    
  
             
    def salvar_carta(self):
        nome = self.entrada.text()

        conn = sqlite3.connect("cartas.db")
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO cartas (nome, imagem)
        VALUES (?, ?)
        """, (nome, self.caminho_imagem))

        conn.commit()
        conn.close()
        


    def abrirImagem(self):
        caminho, _ = QFileDialog.getOpenFileName(
            self,
            "Selecione uma imagem",
            "",
            "Imagens (*.png *.jpg *.jpeg *.bmp *.gif)"
        )

        if caminho:  
            pixmap = QPixmap(caminho)
            pixmap = pixmap.scaled(
            230,
            275,
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
            )  
            self.label_imagem.setFixedSize(230, 275)
            self.label_imagem.move(380, 85)
            self.label_imagem.setPixmap(pixmap)
            self.label_imagem.setScaledContents(False)
            self.caminho_imagem = caminho








class PrimeiraTela(QWidget):
    def __init__(self):
        super().__init__()

        criar_banco()
        
        self.setWindowTitle("Minha Janela")
        self.resize(1000, 700)
        self.setStyleSheet("background-color: #324B76;")

 
        self.botao1 = QPushButton("Criar Carta", self)
        self.botao1.move(20, 450)
        self.botao1.resize(300, 100)
        self.botao1.setStyleSheet("font-size: 34px; font-weight: bold; color: white; background-color: #FFB33E;")
        self.botao1.clicked.connect(self.abrirSegundaTela)


        self.botao2 = QPushButton("Mudar Carta", self)
        self.botao2.move(350, 450)
        self.botao2.resize(300, 100)
        self.botao2.setStyleSheet("font-size: 34px; font-weight: bold; color: white; background-color: #FFB33E;")
        self.botao2.clicked.connect(self.abrirQuartaTela)

        self.botao3 = QPushButton("Remover Carta", self)
        self.botao3.move(680, 450)
        self.botao3.resize(300, 100)
        self.botao3.setStyleSheet("font-size: 34px; font-weight: bold; color: white; background-color: #FFB33E;")
        self.botao3.clicked.connect(self.RemoverCarta)

        self.botao4 = QPushButton("Cartas Criadas", self)
        self.botao4.move(350, 590)
        self.botao4.resize(300, 80)
        self.botao4.setStyleSheet("font-size: 30px; font-weight: bold; color: white; background-color: #08AEF6;")
        self.botao4.clicked.connect(self.abrirTerceiraTela)


        self.titulo = QLabel("Carta preferida atual:", self)
        self.titulo.move(200, 20)
        self.titulo.setStyleSheet("font-size: 60px; font-weight: bold; color: #FFB33E;")


        self.cartaatual = QLabel(self)
        self.cartaatual.move(380, 120)
        pixmap_original = QPixmap("pekka.png")
        pixmap_escalado = pixmap_original.scaled(
            230,
            275,
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )
        self.cartaatual.setPixmap(pixmap_escalado)
        self.cartaatual.adjustSize()   

    def abrirSegundaTela(self):
        self.janela2 = SegundaTela()
        self.janela2.show()

    def abrirTerceiraTela(self):
        self.janela3 = TerceiraTela(self)
        self.janela3.show()
    
    def abrirQuartaTela(self):
        self.janela4 = QuartaTela(self)
        self.janela4.show()
    
    def RemoverCarta(self):
        self.cartaatual.setPixmap(QPixmap(""))

    def mudar_imagem(self, caminho):
        self.cartaatual.setPixmap(QPixmap(caminho))

    def atualizar_imagem(self, caminho):
        pixmap = QPixmap(caminho)
        pixmap = pixmap.scaled(
            230, 275,
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )

        self.cartaatual.setPixmap(pixmap)
        self.cartaatual.setFixedSize(230, 275)
        self.cartaatual.move(385, 120)
            




if __name__ == "__main__":
    app = QApplication(sys.argv)
    janela = PrimeiraTela()
    janela.show()
    sys.exit(app.exec_())
